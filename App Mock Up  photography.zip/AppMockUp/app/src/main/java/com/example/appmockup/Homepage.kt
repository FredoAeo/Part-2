package com.example.appmockup


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView


class Homepage : AppCompatActivity() {

   // private lateinit var
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homepage)

              val upload2 = findViewById<TextView>(R.id.upload2)
        upload2.setOnClickListener{
            val intent = Intent(this, upload ::class.java)
            startActivity(intent)
        }

        val achievements2 = findViewById<TextView>(R.id.achievements2)
        achievements2.setOnClickListener {
            val intent = Intent(this, achievement::class.java)
            startActivity(intent)
        }
    }
}